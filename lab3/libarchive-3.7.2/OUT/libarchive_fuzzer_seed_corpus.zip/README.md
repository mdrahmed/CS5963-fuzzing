Valid files with a payload as small as possible.

Use it to fool parsers and to fit within unexpected size range.
